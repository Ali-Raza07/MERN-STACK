const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');
const teamRoutes = require('./routes/team');
const slideRoutes = require('./routes/slides');

dotenv.config();
const app = express();

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000' }));
app.use(express.json());

// Serve uploaded images as static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/team', teamRoutes);
app.use('/api/slides', slideRoutes);

app.get('/', (req, res) => res.json({ message: 'DevPortfolio API running ✓' }));

mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/devportfolio')
  .then(() => {
    console.log('✅ MongoDB connected');
    app.listen(process.env.PORT || 5000, () =>
      console.log(`🚀 Server on http://localhost:${process.env.PORT || 5000}`)
    );
  })
  .catch(err => console.error('MongoDB error:', err));
