const mongoose = require('mongoose');
const TeamMember = require('./models/TeamMember');
const Slide = require('./models/Slide');
require('dotenv').config();

const teamData = [
  { name:"Ahmed Raza", role:"Developer", bio:"Full-stack MERN developer with 4 years of experience building scalable web apps.", img:"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80", linkedin:"#", github:"#", order:1 },
  { name:"Sara Khan", role:"Designer", bio:"UI/UX designer crafting pixel-perfect interfaces. Figma expert with a passion for motion.", img:"https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80", linkedin:"#", github:"#", order:2 },
  { name:"Ali Hassan", role:"Developer", bio:"Backend Node.js engineer focused on REST APIs and database optimization.", img:"https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80", linkedin:"#", github:"#", order:3 },
  { name:"Fatima Malik", role:"Manager", bio:"Product manager with a background in agile methodologies and team leadership.", img:"https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&q=80", linkedin:"#", github:"#", order:4 },
  { name:"Bilal Akhtar", role:"DevOps", bio:"AWS certified cloud engineer. Docker & Kubernetes expert, CI/CD pipeline builder.", img:"https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=80", linkedin:"#", github:"#", order:5 },
  { name:"Zainab Mir", role:"Designer", bio:"Brand designer and illustrator creating design systems that scale beautifully.", img:"https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&q=80", linkedin:"#", github:"#", order:6 }
];

const slideData = [
  { tag:"MERN Stack", title:"E-Commerce Platform", desc:"Full-stack shopping platform with real-time inventory and payment gateway.", cta:"View Project", img:"https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1600&q=80", color:"#c8f55a", order:1 },
  { tag:"AI Integration", title:"AI Analytics Dashboard", desc:"Machine learning-powered business intelligence with live data visualization.", cta:"See Demo", img:"https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=1600&q=80", color:"#7c6ff7", order:2 },
  { tag:"Mobile App", title:"Social Connect App", desc:"Cross-platform React Native app with real-time messaging and media sharing.", cta:"Learn More", img:"https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=1600&q=80", color:"#ff6b35", order:3 }
];

async function seed() {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/devportfolio');
  await TeamMember.deleteMany({});
  await Slide.deleteMany({});
  await TeamMember.insertMany(teamData);
  await Slide.insertMany(slideData);
  console.log('✅ Database seeded successfully!');
  console.log(`   → ${teamData.length} team members`);
  console.log(`   → ${slideData.length} slides`);
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
