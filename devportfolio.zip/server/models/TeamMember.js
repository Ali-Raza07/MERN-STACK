const mongoose = require('mongoose');

const teamMemberSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  role:     { type: String, required: true, enum: ['Developer','Designer','Manager','DevOps'] },
  bio:      { type: String, default: '' },
  img:      { type: String, default: '' },
  linkedin: { type: String, default: '' },
  github:   { type: String, default: '' },
  order:    { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('TeamMember', teamMemberSchema);
