const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const TeamMember = require('../models/TeamMember');

// Multer config
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e6);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    /jpeg|jpg|png|webp|gif/.test(file.mimetype) ? cb(null, true) : cb(new Error('Images only'));
  }
});

const imgUrl = (req, filename) => `${req.protocol}://${req.get('host')}/uploads/${filename}`;

router.get('/', async (req, res) => {
  try {
    const { search, role } = req.query;
    let query = {};
    if (role && role !== 'All') query.role = role;
    if (search) query.$or = [{ name: { $regex: search, $options: 'i' } }, { bio: { $regex: search, $options: 'i' } }];
    const members = await TeamMember.find(query).sort({ order: 1, createdAt: 1 });
    res.json({ success: true, data: members });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const member = await TeamMember.findById(req.params.id);
    if (!member) return res.status(404).json({ success: false, error: 'Not found' });
    res.json({ success: true, data: member });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

router.post('/', upload.single('image'), async (req, res) => {
  try {
    const data = { ...req.body };
    if (req.file) data.img = imgUrl(req, req.file.filename);
    const member = await TeamMember.create(data);
    res.status(201).json({ success: true, data: member });
  } catch (err) { res.status(400).json({ success: false, error: err.message }); }
});

router.put('/:id', upload.single('image'), async (req, res) => {
  try {
    const data = { ...req.body };
    if (req.file) {
      data.img = imgUrl(req, req.file.filename);
      const existing = await TeamMember.findById(req.params.id);
      if (existing?.img?.includes('/uploads/')) {
        const oldFile = path.join(uploadDir, path.basename(existing.img));
        if (fs.existsSync(oldFile)) fs.unlinkSync(oldFile);
      }
    }
    const member = await TeamMember.findByIdAndUpdate(req.params.id, data, { new: true, runValidators: true });
    if (!member) return res.status(404).json({ success: false, error: 'Not found' });
    res.json({ success: true, data: member });
  } catch (err) { res.status(400).json({ success: false, error: err.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    const member = await TeamMember.findByIdAndDelete(req.params.id);
    if (!member) return res.status(404).json({ success: false, error: 'Not found' });
    if (member.img?.includes('/uploads/')) {
      const file = path.join(uploadDir, path.basename(member.img));
      if (fs.existsSync(file)) fs.unlinkSync(file);
    }
    res.json({ success: true, message: 'Member deleted' });
  } catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

module.exports = router;
